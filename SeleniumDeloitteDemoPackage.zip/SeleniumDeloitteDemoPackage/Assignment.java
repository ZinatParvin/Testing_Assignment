package SeleniumDeloitteDemoPackage;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment {
		public static void main(String args[]){
			
			System.setProperty("webdriver.chrome.driver","C://chromedriver//chromedriver.exe");
			
			WebDriver driver=new ChromeDriver();
			
			driver.get("https://makemytrip.com/");
			
			//maximize window
			driver.manage().window().maximize();
					
			//finding the element using the locator	
			driver.findElement(By.className("makeFlex")).click();
			driver.findElement(By.id("username")).sendKeys("zinat786parvin@gmail.com");
			driver.findElement(By.cssSelector(".modalLogin")).click();
			
			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			driver.findElement(By.id("password")).sendKeys("zinat@22");
			try {
				Thread.sleep(400);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			driver.findElement(By.cssSelector("button")).click();
		}
		
}
