package SeleniumDeloitteDemoPackage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class NewTestNGTestPriority {
	@Test(priority = 1)
	public void launchGoogle() {

		System.setProperty("webdriver.chrome.driver", "C://chromedriver//chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.google.co.in");

		driver.manage().window().maximize();
	}

	@Test(priority = 2)
	public void performSearchAndClick1stLink() {

		System.setProperty("webdriver.chrome.driver", "C://chromedriver//chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.google.co.in");
		
		driver.manage().window().maximize();

		driver.findElement(By.name("q")).sendKeys("linkedIn");

		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(priority = 3)
	public void FaceBookPageTitleVerification() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C://chromedriver//chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.google.co.in");
		
		driver.manage().window().maximize();

		driver.findElement(By.name("q")).sendKeys("linkedIn");

		driver.findElement(
				By.cssSelector("#tsf > div:nth-child(2) > div.A8SBwf > div.FPdoLc.tfB0Bf > center > input.gNO89b"))
				.click();

		Thread.sleep(4000);
	}

}
