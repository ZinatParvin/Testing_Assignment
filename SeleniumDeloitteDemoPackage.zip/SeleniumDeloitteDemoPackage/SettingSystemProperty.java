package SeleniumDeloitteDemoPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SettingSystemProperty {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C://chromedriver//chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://linkedIn.com");
		
		//maximize window
		driver.manage().window().maximize();
				
		
		//finding the element using the locator	
		driver.findElement(By.cssSelector("body > nav > a.nav__button-secondary")).click();
		driver.findElement(By.name("session_key")).sendKeys("parvinzinat22@gmail.com");
		driver.findElement(By.name("session_password")).sendKeys("zinat@link");
		
		
	}
} 